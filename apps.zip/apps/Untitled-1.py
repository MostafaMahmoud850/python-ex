numbers = [1, 3, 2, 5, 4, 7, 6]

numbers.sort(reverse=False)

# print(numbers)
# print(sorted(numbers))


# import math

# print(math.sqrt(10000))


print(list(enumerate(numbers)))

for index, item in enumerate(numbers):
    print(f"in index ( {index} ) the item is ---> {item}")

print(50 * "=")


degrees = {"Mostafa" : "77%", "Mahmoud" : "60%", "Yacoup" : "80%"}

index = 0
for key, value in degrees.items():

    print(f"{key} has {value} degree and index: {index}")
    index += 1


print(50 * "=")

for index, item in enumerate(degrees.items()):

    key, value = item
    print(f"{key} has {value} degree and index: {index}")

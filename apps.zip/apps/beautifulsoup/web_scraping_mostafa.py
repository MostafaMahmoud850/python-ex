import requests
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest

job_titles = []
links = []
company_names = []
locations = []
date = []
skills_and_type_job = []

page_num = 0

while page_num < 100:
    try:
        url = f"https://wuzzuf.net/search/jobs/?a=navbl%7Cspbl&q=data%20analysis&start={page_num}"
        response = requests.get(url)

        # get the content from url selected
        page = response.content # page is bytecode <class 'bytes'>
        soup = BeautifulSoup(page, "lxml") 
        # converting from bytes to html tags by using parser

        # continers are list of elements, each div is a continer
        continers = soup.find_all("div", {"class": "css-1gatmva e1v1l3u10"}) 
        # print(len(continers)) # 15 for each page
        # print(type(continers)) # <class 'bs4.element.ResultSet'> 
        for i in range(len(continers)):
            job_title = continers[i].find("h2", {"class": "css-m604qf"}).text.strip()
            job_titles.append(job_title)
            company_name = continers[i].find("div", {"class": "css-d7j1kk"}).a.text.strip()
            company_names.append(company_name)
            location = continers[i].find("span", {"class": "css-5wys0k"}).text.strip()
            locations.append(location)
            try:
                posted = continers[i].find("div", {"class": "css-do6t5g"}).text.strip()
            except:
                posted = continers[i].find("div", {"class": "css-4c4ojb"}).text.strip()
            date.append(posted)
            job_skills = continers[i].find("div", {"class": "css-y4udm8"}).text.strip()
            skills_and_type_job.append(job_skills)
            link = continers[i].find("a", {"class": "css-o171kl"}).attrs["href"]
            links.append(link)

            # print(job_title, company_name, location, posted, job_skills, link)
    except (UnicodeEncodeError, UnicodeEncodeError):
        print("error")
        continue

    print(f"page switched: {page_num}")
    page_num += 1

file_list = [job_titles, company_names, locations, date, skills_and_type_job, links]
exported = zip_longest(*file_list)

with open("test.csv", "w", encoding="utf-8") as my_file:
    wr = csv.writer(my_file)
    wr.writerow(["job title", "company name", "location", "date of post", "skills", "link"])
    wr.writerows(exported)


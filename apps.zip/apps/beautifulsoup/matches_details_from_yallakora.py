import requests
from bs4 import BeautifulSoup
import csv

# pip install requests
# pip install beautifulsoup4
# pip install lxml

# get date of day from the user for example ---> 11/1/2023
date = input("please enter a date in the following format MM/DD/YYYY: ")

# send an HTTP request to the website's server to retrieve the HTML
url = f"https://www.yallakora.com/match-center/%D9%85%D8%B1%D9%83%D8%B2-%D8%A7%D9%84%D9%85%D8%A8%D8%A7%D8%B1%D9%8A%D8%A7%D8%AA?date={date}#" # or "".format(date)

# first: get the page and store it in variable (page or response); 
# second: get content of the page and store it in variable (source > src);
response = requests.get(url)

def main(page):

    src = response.content ### the content is returned in a picture (byte code) ###
    # display content of the page --> note: (byte code)
    # print(response.content) 
    # (response.text) is the content of the response in Unicode, and (response.content) is the content of the response in bytes.

    # parsing is converting byte code to HTML tag to handle it;
    # parse the HTML of the page  (lxml or html.parser) by Beautifulsoup library;
    soup = BeautifulSoup(src, "lxml")
    # display the HTML code of the page 
    # print(soup)
    matches_details = []

    # Method signature: find_all(name, attrs, recursive, string, limit, **kwargs)

    # The find_all() method looks through a tag’s descendants and retrieves all descendants that match your filters. I gave several examples in Kinds of filters, but here are a few more:
    championships = soup.find_all("div", {"class": "matchCard"}) # all class or part of class for,for example --> championship = soup.find_all("div", {"class": "matchCard"})
    # print(championship)
    # championship is a list consisting of more than one value each value is a code of one championship in the day selected  ---> list of elements


    # A tag’s children are available in a list called .contents ---> list of elements
    def get_match_info(championship):
        championship_title = championship.contents[1].find("h2").text.strip()#contents[0] returned <int> object(-1)

        # AttributeError: ResultSet object has no attribute 'contents'. You're probably treating a list of elements like a single element. Did you call find_all() when you meant to call find()?
        print(championship_title)
        
        # championship_team1 = championship.contents[3].find("div", {"class": "teamA"}).text.strip()
        # print(championship_team1)
        all_matches = championship.contents[3].find_all("div", {"class": "liItem"})
        # print(all_matches)
        number_of_matches = len(all_matches)
        print(f"number of matches: {number_of_matches}")

        
        for i in range(number_of_matches):
            # get teams names
            team_A = all_matches[i].find("div", {"class": "teamA"}).text.strip()
            team_B = all_matches[i].find("div", {"class": "teamB"}).text.strip()
            # get score for each team
            match_results = all_matches[i].find("div", {"class": "MResult"}).text.strip()
            score_team_A = match_results[0]
            score_team_B = match_results[4]
            score = f"({score_team_A} - {score_team_B})"
            # get time of match
            match_time = all_matches[i].find("span", {"class": "time"}).text.strip()
            # print(championship_title, team_A, score_team_A, "-", score_team_B, team_B, match_time)

            # add match info to matches_details
            matches_details.append({"نوع البطولة": championship_title, "الفريق الأول": team_A, "الفريق الثانى": team_B, "ميعاد المباراة": match_time, "نتيجة المبارة": score})


    for i in range(len(championships)):
        get_match_info(championships[i])

    keys = matches_details[0].keys()

    with open(r"C:\Users\mostafa\matches-details.csv", "w") as output_file:
        dict_writer = csv.DictWriter(output_file, keys)
        dict_writer.writeheader()
        dict_writer.writerows(matches_details)
        print("file created")


main(response)
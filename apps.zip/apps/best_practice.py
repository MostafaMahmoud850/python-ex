# import sys
# sys.argv[1] I can type a command value in command line but if i run without python file.py argument will be there IndexError: list index out of range
command = "do" 
match command:
    case "do":
        print("do")
    case "hey":
        print("hey")
    case _:
        print("I did not understand")

print("=" * 50)

# Dictionary instead if elif else many times.
pizza_price = 10
toppings_prices = {
    "Olives": 3,
    "Pepperoni": 10,
    "Mushrooms": 5,
    "Pineapple": 8,
}
desired_topping = input(
    "What toppings would you like on your pizza?\n Olives | Pepperoni | Mushrooms | Pineapple: "
).capitalize().strip()
# dt = Desired Topping
dt_price = toppings_prices.get(desired_topping)

if pizza_price:
    pizza_price += dt_price

print(f"Final price: {pizza_price}")

print("=" * 50)

def show_toppings_prices(**toppings):
    for topping, price in toppings_prices.items():
        print(f"price topping {topping} is: {price}")

show_toppings_prices(**toppings_prices)
# should to be two key and value (dict) --> else Error
show_toppings_prices(Olives=3, Pepperoni=10, Mushrooms=5, Pineapple=8,)


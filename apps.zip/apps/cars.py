class Car():
    def __init__(self, color, model, year, price):
        self.color = color
        self.model = model
        self.year = year
        self.price = price


    def mycar(self):

        if self.year >= 2018:
            self.price *= 1.1
            return  f"New price is: {self.price}"

        else:
            self.price *= 0.95
            return f"New price is: {self.price}"


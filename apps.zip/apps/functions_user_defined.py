CLEAR = "\033[2J"
CLEAR_AND_RETURN = "\033[H"
def main():
    get_int("enter integer: \n")
    get_float("Enter float: \n")    
    get_positive_number()
    
def get_int(prompt):    
    while True:
        try:
            return int(float(input(prompt)))
        except ValueError:
            pass
    
def get_float(prompt):
    while True:
        try:
            return float(input(prompt))   
        except ValueError:
            pass

def get_positive_number():
    while True:
        n = input(f"{CLEAR} {CLEAR_AND_RETURN} please enter integer number > 0: ")
        try:
            n = int(n)
        except ValueError:
            print(f"{n} is not an integer, please try again!")
            continue # TypeError: '<=' not supported between instances of 'str' and 'int'

        if n <= 0:  # if n > 0 : break
            print(f"{n}")
        else:
            return n


main()
def even_odd_checker():

    number:int = int(input("Enter your number: "))

    if number % 2 == 0:
        print(f"{number} is Even number.")

    else:
        print(f"{number} is Odd number.")

even_odd_checker()



def is_even(number) -> bool:

    if number % 2 == 0:
        # return f"{number} is Even number."
        return True
    else:
        # return f"{number} is Odd number."
        return False

print(is_even(2))



def is_odd(number) -> bool:
    
    if number % 2 != 0:
        # return f"{number} is Odd number."
        return True
    else:
        # return f"{number} is Even number."
        return False
    
print(is_odd(250))
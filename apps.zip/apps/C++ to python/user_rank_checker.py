points:int = int(input("Please enter your points te get your rank: "))

if 0 < points <= 500:
    print("Your rank is not bad.")
elif 500 < points <= 1000:
    print("Your rank is very good.")
elif points > 1000:
    print("Your rank is VIP.")


age = 25
num = 25

print(id(age), id(num)) # The same location in memory.


operation = "*"

match operation:
    case "*" | "+" | "-":
        print(operation)
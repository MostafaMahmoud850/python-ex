number_1:int = int(input("please enter your first number: "))
number_2:int = int(input("please enter your second number: "))
number_3:int = int(input("please enter your third number: "))

if number_1 > number_2 and number_1 > number_3:
    print(f"{number_1} is the greatest number of three.")

elif number_2 > number_3:
    print(f"{number_2} is the greatest number of three.")

else:
    print(f"{number_3} is the greatest number of three.")




list_a = [1, 2, 3]
list_b = [1, 2, 3]
 
print(list_a == list_b)  # output: True
print(list_a is list_b)  # output: False


 
print(list_b == list_b)  # output: True
print(list_b is list_b)  # output: True
import sys, os
from PIL import Image, ImageOps


def main():

    check_command_line_args()

    try:

        image = Image.open(sys.argv[1])

    except FileNotFoundError:
        sys.exit("Input does not exist")

    shirt = Image.open("shirt.png")

    size = shirt.size

    muppet = ImageOps.fit(image, size)

    muppet.paste(shirt, shirt)

    muppet.save(sys.argv[2])


valid_input = ["png", "jpg", "jpeg"]

def check_command_line_args():

    if len(sys.argv) < 3:
        sys.exit("Too few command-line arguments")

    elif len(sys.argv) > 3:
        sys.exit("Too many command-line arguments")

    elif sys.argv[1][-3:] not in valid_input or sys.argv[2][-3:] not in valid_input:
        sys.exit("Invalid input")

    name, ext_1 = os.path.splitext(sys.argv[1])
    name, ext_2 = os.path.splitext(sys.argv[2])

    if ext_1 != ext_2:
        sys.exit("Input and output have different extensions")



if __name__ == "__main__":
    main()
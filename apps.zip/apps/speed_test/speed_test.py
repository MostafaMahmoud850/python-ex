from speedtest import Speedtest

wifi = Speedtest()

print("Getting Download Speed...")
download = wifi.download() # return bit at second --> we need to convert it to megabyte a second 
print(f"Download: {download / 1024 / 1024:.2f} mbps")

print("Getting Upload Speed...")
upload = wifi.upload() # return bit at second --> we need to convert it to megabyte a second
print(f"Upload: {upload / 1024 /1024:.2f} mbps")

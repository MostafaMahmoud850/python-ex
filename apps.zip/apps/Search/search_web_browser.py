import webbrowser
search = input('search : ')
webbrowser.open('https://www.google.com/search?q=' + search)
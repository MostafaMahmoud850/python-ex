from cars import Car

toyta = Car("Toyta", "Camry", 2015, 60000)
bmw = Car("bmw", "3 series", 2018, 80000)
ford = Car("ford", "Mustang", 2020, 90000)


print(ford.mycar())

print(toyta.color, toyta.year, toyta.price, toyta.model, bmw.price, ford.price)







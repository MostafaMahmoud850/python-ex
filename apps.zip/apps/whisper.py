import whisper
print(dir(whisper))
#  Load the whisper model

model = whisper.load_model("base") # tiny

print("Model loaded")

# transcribe the audio
# 
result = model.transcribe("path to convert")

with open("result.txt", "w") as file:
    file.write(result["text"])

print("Done")
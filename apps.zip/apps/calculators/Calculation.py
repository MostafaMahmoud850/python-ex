import pyttsx3

CLEAR: str = "\033[2J"
CLEAR_AND_RETURN:str = "\033[H"


def main():
    positive: int = get_positive_number()
    for _ in range(positive):
        print(f"{CLEAR} {CLEAR_AND_RETURN}")
        calculation()
        repeat: str = (
            input("Do you want to perform another operation (yes/no): ").strip().lower()
        )
        if repeat != "yes":
            print("Program exited")
            return 0


def calculation() -> None:
    def print_and_say_result() -> None:
        print(f"{num1} {operation} {num2} = {round(result, 2)}")
        say_result(result)

    num1: float = get_float()

    operation: str = get_operator()

    num2: float = get_float()

    match operation:  # if operation in operations:
        case "+":
            result: float = num1 + num2
            print_and_say_result()
        case "-":
            result: float = num1 - num2
            print_and_say_result()
        case "*":
            result: float = num1 * num2
            print_and_say_result()
        case "/":
            num2 = check_ZeroDivisionError(num2)
            result: float = num1 / num2
            print_and_say_result()
        case "%":
            result: float = num1 % num2
            print_and_say_result()
        case "//":
            num2 = check_ZeroDivisionError(num2)
            result: float = num1 // num2
            print_and_say_result()
        case "**":
            result: float = num1**num2
            print_and_say_result()


def print_and_say_invalid_messeage(integer: int) -> None:
    print(f"{integer} is an Invaild, Please type a positive number, please try again!")
    engine = pyttsx3.init()
    engine.say(
        f"{integer} is an Invaild, Please type a positive number, please try again!"
    )
    engine.runAndWait()


def say_result(result: float) -> None:
    engine = pyttsx3.init()
    engine.say(f"the result is: {round(result, 2)} ")
    engine.runAndWait()


def get_float() -> float:
    while True:
        num: str = input("Enter the number: \n")
        try:
            return float(num)
        except ValueError:
            print(f"{num} is an Invalid, please type a number!")
            engine = pyttsx3.init()
            engine.say(f"{num} is an Invalid, please type a number!")
            engine.runAndWait()


def get_operator() -> str:
    operations = ["+", "-", "*", "/", "%", "//", "**"]
    operation: str = input(
        "Enter an operation to perform > (+ , - , * , / , % , // , **) < : \n"
    )
    if operation in operations:
        return operation
    else:
        print(
            f"{operation} is an Invalid, please enter any of these operations {operations}"
        )
        engine = pyttsx3.init()
        engine.say(
            f"{operation} is an Invalid, please enter any of these operations {operations}"
        )
        engine.runAndWait()
        get_operator()  # recursive function call

def check_ZeroDivisionError(num2: float) -> float:
    while True:
        if num2 == 0:
            print("please enter numeric value != 0")
            engine = pyttsx3.init()
            engine.say(f"{num2} is an invalid, !")
            engine.runAndWait()           
            calculation() # handling ZeroDivisionError
        else:
            return num2
        


def get_positive_number() -> int:
    while True:
        n: str = input(
            f"{CLEAR} {CLEAR_AND_RETURN} \t\t<<< welcome in Calculator program >>>\n\n how many time for call function? please enter integer number > 0: "
        )

        try:
            n = int(n)   
            if n > 0: # if n > 0 : return and break
                return n
            else:
                print_and_say_invalid_messeage(n)
                continue

        except ValueError:
            print(f"{n} is not an integer, please try again!")
            engine = pyttsx3.init()
            engine.say(f"{n} is not an integer, please try again!")
            engine.runAndWait()
            

if  __name__ == '__main__':
    main()


from Calculation import main

main()
# 1st step install and import modules
# pip/pip3 install lxml
# pip/pip3 install requests
# pip/pip3 install BeautifulSoup4
import requests
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest

job_title = []
company_name = []
location_name = []
skills = []
link = []
salary = []
responsibilities = []
date = []
page_num = 0
# while True:
# try:
# 2nd step use requests to fetch the url
result = requests.get(f"https://wuzzuf.net/search/jobs/?a=navbl&q=python&start={page_num}")

# 3rd step save page content/markup
src = result.content
# print(src)

# 4th step create soup object to parse
soup = BeautifulSoup(src, "lxml")
continers = soup.find_all("div", {"class": "css-1gatmva e1v1l3u10"})
# page_limit = int(soup.find("strong").text.strip())

# if (page_num > page_limit // 15):
#     print("pages ended, terminate")
#     break

for i in range(len(continers)):
# 5th step find the elements containing info we need
# job titles, job skills, company names, location names
    job_titles = continers[i].find("h2", {"class":"css-m604qf"}).text
    job_title.append(job_titles)
    company_names = continers[i].find("div", {"class":"css-d7j1kk"}).text
    company_name.append(company_names)
    location_names = continers[i].find("span", {"class":"css-5wys0k"}).text
    location_name.append(location_names)
    job_skills = continers[i].find("div", {"class":"css-y4udm8"}).text
    skills.append(job_skills)
    try:
        posted = continers[i].find("div", {"class":"css-do6t5g"}).text  
    except:
        posted = continers[i].find("div", {"class":"css-4c4ojb"}).text
    date_text = posted.replace("-", "").strip()
    date.append(date_text)
    links = continers[i].h2.a.attrs["href"]
    link.append(links)
# 6th steo kiio iver returned lists to extract needed ifo into other lists
    
# page_num += 1
print("page switched")            
# except:
#     print("Error occurred")
#     # break

# for link in links:
#     result = requests.get(link)
#     src = result.content
#     soup = BeautifulSoup(src, "lxml")
#     job_details = soup.find("section", {"class": "css-3kx5e2"})
#     salaries = soup.find("div", {"class":"css-rcl8e5","class": "css-47jx3m", "class":"css-4xky9y"})
#     salary.append(salaries)
#     print(salary)
#     requirements = soup.find("div", {"class":"css-1t5f0fr"}).text.strip()
    
    
#     respon_text += requirements+"| "
#     respon_text = respon_text[:-2]
#     responsibilities.append(respon_text)


# 7th step create csv file and fill it with values
file_list = [job_title, company_name, date, location_name, skills, links, salary, responsibilities]
exported = zip_longest(*file_list)


with open("C:/Users/mostafa/Desktop/calc/jobs.csv", "w") as myfile:
    wr = csv.writer(myfile)
    wr.writerow(["job title", "company name", "date", "location", "skills", "links", "salary", "responsibilities"])
    wr.writerows(exported)

# 8th step to fetch the link of the job and fetch in page details
# salary, job requirements


# 9th step is to do the above for all pages

# 10th step is to optimize code and clean data


# i = 1

# while i <= 10:
#     i += 1
#     if i == 11:
#         break
#     print(pow(i, 2))
    
# else:
#     print("the condition is not True")
# print("the loop is ended")
# import time
# from threading import Thread

# start_time = time.time()

# def task1():
#     print("start tast1....")
#     time.sleep(9)
#     print("End tast1")

# def task2():
#     print("start tast2....")
#     time.sleep(4)
#     print("End tast2")

# def task3():
#     print("start tast3....")
#     time.sleep(3)
#     print("End tast3")

# threadList = []
# threadList.append(Thread(target = task1))
# threadList.append(Thread(target = task2))
# threadList.append(Thread(target = task3))

# for t in threadList:
#     t.start()
# for t in threadList:
#     t.join

# print(f"--- {time.time() - start_time:.5f} seconds --- \n\r")



# methods and operators overloading
class Order:
    def __init__(self, cart, customer):
        self.cart = cart
        self.customer = customer
    
    # Return integer --> else Error
    def __len__(self):
        return len(self.cart)
    
    # return inforrmation when call object, for example --->  order() 
    def __call__(self):
        print(f"{self.customer}")
    
    # Return string --> else Error
    def __str__(self):
        return f"name: {self.customer}, bought: {self.cart}"
    
    # return repersentation of class
    def __repr__(self):
        return "Order(list of items, customer name)"
    
    # return cart fill or empty ---> True or False
    def __bool__(self):
        return len(self.cart) > 0
    
    # add item in the end list
    def add_item(self, other):
        return self.cart.append(other)

    # variable = variable + new value, x = 5 --> x = x + 5
    def __add__(self, other):
        new_cart = self.cart.copy()
        new_cart.append(other)
        return Order(new_cart, self.customer)
    
    # variable += newvalue, x = 5 -->  x += 5
    def __iadd__(self, other):
        self.cart.append(other)
        return self
    # reverse add to insert values in first list
    def __radd__(self, other):
        new_cart = self.cart.copy()
        new_cart.insert(0, other)
        return Order(new_cart, self.customer)
    
# get item from list dirctly without cart. from --> order.cart[key]. to --> order[key]
    def __getitem__(self, key):
        return self.cart[key]
    
# change item in list dirctly without cart. from --> order.cart[key] = value. to --> order[key] = value.
    def __setitem__(self, key, value):
        self.cart[key] = value
        return self
    
'''    
(multiplication * , divination / , subtraction - ) oprerators
__mul__ v = v * v, __imul__ v *= v , __div__ v = v / v, __idiv__ v /= v , __sub__ v = v - v, __isub__ v -= v
'''

order = Order(["laptop", "monitor", "mouse"], "islam hesham")

print(len(order))
order()
print(order)
print(repr(order))
if order:
    print(f"{order.customer}: order is processing")
else:
    print("shopping cart is empty")
order.add_item("keyboard")
print(order.cart)
order = order + "usb stick"
order += "case"
print(order.cart)
order = "usb cable" + order
print(order.cart)
print(order[-1])
order[-1] = "PC"
print(order[-1])
print(order.cart)


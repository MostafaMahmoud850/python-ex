import emoji
print(dir(emoji))
user_input = input("Input: ")

if user_input.startswith(":"):
    print(f"Output: {emoji.emojize(user_input)}")
else:
    string, user_input = user_input.split()
    print(f"Output: {string} {emoji.emojize(user_input)}")
import re

# email = input("What's your email? ").strip()

# if re.search(r"^\w+@\w+\.edu$", email, flags=re.IGNORECASE):
#     print("Valid")
# else:
#     print("Invalid")

# name = input("What's your name? ").strip()

# if matches := re.search(r"^(.+), *(.+)$", name):
#     name = matches.group(2) + " " + matches.group(1)

# print(f"hello, {name}")

url = input("URL: ").strip()

# username = re.sub(r"^(https?://)?(www\.)?twitter\.com/", "", url)

# print(f"Username: {username}")


matches = re.search(r"https?://(?:www\.)?twitter\.(.+)/([a-z0-9_]+)", url, re.IGNORECASE)

if matches.group(1) == "com":
    
    print("Username:", matches.group(2))



print("mostafa" + " " +"mahmoud")
print((1, 2) + (3, 4))
print([1, 2] + [3, 4])
print((1, 2) + (3, 4))
print(5 + 3)

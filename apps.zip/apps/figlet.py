from pyfiglet import Figlet
import sys

figlet = Figlet()
fonts = figlet.getFonts()
print(fonts)

if len(sys.argv) < 3:
    sys.exit()

if sys.argv[2] in fonts:
    match sys.argv[1]:
        case "-f" | "--font":
            figlet.setFont(font=sys.argv[2])
            prompt = input("Input: ")
            print(figlet.renderText(prompt))
        case _:
            sys.exit()
else:
    sys.exit()


